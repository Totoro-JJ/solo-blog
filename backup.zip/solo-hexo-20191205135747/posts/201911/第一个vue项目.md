title: 第一个vue项目
date: '2019-11-30 11:00:17'
updated: '2019-11-30 11:02:03'
tags: [vue]
permalink: /articles/2019/11/30/1575082817052.html
---
## 准备
#### 首先，在接触Vue.js前：
* 你要会用html，css，js/jquery写一些简单的页面
* 要了解vue只是前台的一个框架，而并非是一门新语言
#### 接下来，咱们进入正题吧。
## 正文
### Vue.js的安装
1. 独立版本
我们可以在 Vue.js 的官网上直接下载 vue.min.js 并用`<script>`标签引入
2.  NPM 方法
这个有基础的朋友可以去了解node.js构建vue项目，这里就不做过多解释
### 代码测试
在桌面新建一个text.html文件，复制以下代码即可
```
    <!DOCTYPE html>
    <html>
    <head>
        <title></title>
	<!-- 引入vue.js-->
        <script type="text/javascript" src="https://unpkg.com/vue"></script>
    </head>
    <body>
    <div id="firstVue">
    </div>
    </body>
    <script type="text/javascript">
        var myVue = new Vue({
            el:"#firstVue"
        })
    </script>
    </html>
```
到这一步，基本的搭建已经做完了，这里就不作截图了，因为没有进行数据绑定，页面是一片空白😰 ，耐心点，接着往下看，嘿嘿！！！
```
    <!DOCTYPE html>
    <html>
    <head>
        <title></title>
        <script type="text/javascript" src="https://unpkg.com/vue"></script>
    </head>
    <body>
    <div id="firstVue">
    {{myData}}
    </div>
    </body>
    <script type="text/javascript">
        var myVue = new Vue({
            el:"#firstVue",
            data:{
                myData:"test"
            }
        })
    </script>
    </html>
```
到这一步，页面显示出test，则证明你的第一个vue项目已经搭建完成了
## 总结
最后，跟大家解释一下其中的知识点：
`{{myData}}`  这个双大括号的语法叫做**mustache** 语法，
el和data属于同级，不要搞错啦！！
#### 上面会感觉写的很啰嗦 ，下次尽量深入Vue.js的进阶内容讲一下

